Course Name: CS373
Unique: 91055
Team Name: All the Single Ladies

First Name:					Jake
Last Name:					Wilke
EID:						jlw3599
E-mail:						jake.wilke@gmail.com
Estimated number of hours:	50
Actual    number of hours:	60

Turnin CS Username:		jwilke
GitHub ID:				Kieldro
GitHub Repository Name:	cs373-wc
Google App Engine URL:	jwilke-cs373-wc.appspot.com

--------------------
Group Member Information
--------------------

Member First Name:			Fayz
Member Last Name:			Rahman
Member EID:					fnr75
Member E-mail:				fayz.rahman@utexas.edu
Member Rating:				Excellent
Member Point Adjustment:		+1

Member First Name:			Ian
Member Last Name:			Buitrago
Member EID:					ib
Member E-mail:				kieldro@gmail.com
Member Rating:				Satisfactory
Member Point Adjustment:		-2

Member First Name:			George
Member Last Name:			Shwarts
Member EID:					grs626
Member E-mail:				grsshwarts@utexas.edu
Member Rating:				Excellent
Member Point Adjustment:		+0

Member First Name:			Robert
Member Last Name:			Reed
Member EID:					rer945
Member E-mail:				callmeelasinthe@gmail.com
Member Rating:				Excellent
Member Point Adjustment:		+1

Comments:
UML diagram link: http://www.gliffy.com/pubdoc/3716424/L.png
technical report google doc link: https://docs.google.com/document/d/1El9z6Oz3C8BRXFNfO1kWHEPpxlpYz8lUTqz06gtYTZg/edit


--------------------
Group Member Ratings
--------------------

Excellent: consistently went above and beyond; tutored partner; carried more than her fair share of the load.

Very Good: consistently did what she was supposed to do; very well prepared and cooperative.

Satisfactory: usually did what she was supposed to do; minimally prepared and cooperative.

Marginal: sometimes failed to show up; rarely prepared.

Deficient: often failed to show up; rarely prepared.

Unsatisfactory: consistently failed to show up; unprepared.

Superficial: practically no participation.

No Show: no participation at all.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
