Course Name: CS373
Unique: 91055
Team Name: All the Single Ladies

First Name:					Ian
Last Name:					Buitrago
EID:						ib
E-mail:						kieldro@gmail.com
Estimated number of hours:	30
Actual    number of hours:	40

Turnin CS Username:		rshwarts
GitHub ID:				Kieldro
GitHub Repository Name:	cs373-wc
Google App Engine URL:	jwilke-cs373-wc.appspot.com

--------------------
Group Member Information
--------------------

Member First Name:			Fayz
Member Last Name:			Rahman
Member EID:					fnr75
Member E-mail:				fayz.rahman@utexas.edu
Member Rating:				Excellent
Member Point Adjustment:	NA	<only if you're leader>

Member First Name:			Jake
Member Last Name:			Wilke
Member EID:					jlw3599
Member E-mail:				jake.wilke@gmail.com
Member Rating:				Excellent
Member Point Adjustment:	NA	<only if you're leader>

Member First Name:			George
Member Last Name:			Shwarts
Member EID:					grs626
Member E-mail:				grsshwarts@utexas.edu
Member Rating:				Excellent
Member Point Adjustment:	NA	<only if you're leader>

Member First Name:			Robert
Member Last Name:			Reed
Member EID:					rer945
Member E-mail:				callmeelasinthe@gmail.com
Member Rating:				Excellent
Member Point Adjustment:	NA	<only if you're leader>

Comments:
UML diagram link: http://www.gliffy.com/pubdoc/3716424/L.png
technical report google doc link: https://docs.google.com/document/d/1El9z6Oz3C8BRXFNfO1kWHEPpxlpYz8lUTqz06gtYTZg/edit


--------------------
Group Member Ratings
--------------------

Excellent: consistently went above and beyond; tutored partner; carried more than her fair share of the load.

Very Good: consistently did what she was supposed to do; very well prepared and cooperative.

Satisfactory: usually did what she was supposed to do; minimally prepared and cooperative.

Marginal: sometimes failed to show up; rarely prepared.

Deficient: often failed to show up; rarely prepared.

Unsatisfactory: consistently failed to show up; unprepared.

Superficial: practically no participation.

No Show: no participation at all.

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
